import sys
from pathlib import Path

sys.path.extend([str(Path(__file__).parent.parent.parent)])